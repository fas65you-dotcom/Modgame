package com.example.mobdodger

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private val REQ = 42

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "1. Включите службу доступности MobDodger.\n" +
                "2. Нажмите «Запустить» и разрешите запись экрана.\n" +
                "3. Откройте игру (в ландшафте). Бот убегает от мобов сам.\n" +
                "Остановить: кнопка «Стоп» в уведомлении."
        })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("1. Служба доступности") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. Запустить") {
            val m = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(m.createScreenCaptureIntent(), REQ)
        }
        btn("Стоп") { startService(Intent(this, BotService::class.java).setAction("STOP")) }
        setContentView(root)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, BotService::class.java).putExtra("code", res).putExtra("data", data))
        }
    }
}
