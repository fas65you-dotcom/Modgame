package com.example.mobdodger

/** Все настройки. Координаты - доля экрана в ландшафте (0..1). */
object Config {
    // Центр джойстика (в видео: левый нижний угол)
    const val JOY_CX = 0.155f
    const val JOY_CY = 0.713f
    const val JOY_R = 0.10f        // радиус хода джойстика, доля высоты экрана

    // Дистанции в долях высоты экрана
    const val DANGER = 0.42f       // моб ближе - начинаем убегать
    const val CLEAR = 0.52f        // убегаем, пока все мобы не дальше этого
    const val BODY_OFFSET = 0.042f // тело моба ниже его полоски HP

    const val TICK_MS = 100L
    const val MIN_BAR_PX = 5       // мин. длина полоски HP в уменьшенном кадре
}
