package com.example.mobdodger

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.WindowManager
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class BotService : Service() {

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    @Volatile private var running = false
    private var worker: Thread? = null

    private var realW = 0; private var realH = 0
    private var dirX = 0f; private var dirY = 0f
    private var fleeing = false
    private var lastNotify = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        val data = intent?.getParcelableExtra<Intent>("data") ?: run { stopSelf(); return START_NOT_STICKY }
        val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "Bot", NotificationManager.IMPORTANCE_LOW))
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, notif("Запуск…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, notif("Запуск…"))

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = android.graphics.Rect()
        if (Build.VERSION.SDK_INT >= 30) b.set(wm.currentWindowMetrics.bounds)
        else { val p = android.graphics.Point(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(p); b.set(0, 0, p.x, p.y) }
        realW = max(b.width(), b.height()); realH = min(b.width(), b.height()) // игра в ландшафте
        val w = realW / 2; val h = realH / 2

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, Handler(Looper.getMainLooper()))
        }
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay("bot", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)

        running = true
        worker = Thread {
            while (running) {
                val t = System.currentTimeMillis()
                val img = reader?.acquireLatestImage()
                if (img != null) { try { analyze(img) } finally { img.close() } }
                val dt = System.currentTimeMillis() - t
                if (dt < Config.TICK_MS) Thread.sleep(Config.TICK_MS - dt)
            }
        }.also { it.start() }
        return START_NOT_STICKY
    }

    private class Bar(var y0: Int, var y1: Int, var x0: Int, var x1: Int)

    private fun analyze(img: Image) {
        val W = img.width; val H = img.height
        val pl = img.planes[0]; val buf = pl.buffer; val rs = pl.rowStride; val ps = pl.pixelStride

        // Розовая заливка полоски HP моба
        fun bar(x: Int, y: Int): Boolean {
            val i = y * rs + x * ps
            val r = buf.get(i).toInt() and 255; val g = buf.get(i + 1).toInt() and 255; val b = buf.get(i + 2).toInt() and 255
            return r > 170 && r - g > 60 && b > g && b < 190 && g > 70
        }

        val bars = ArrayList<Bar>()
        val xa = (W * 0.12f).toInt(); val xb = (W * 0.86f).toInt()
        val ya = (H * 0.04f).toInt(); val yb = (H * 0.80f).toInt()
        for (y in ya until yb) {
            var x = xa
            while (x < xb) {
                if (bar(x, y)) {
                    val s = x
                    while (x < xb && bar(x, y)) x++
                    if (x - s >= Config.MIN_BAR_PX) {
                        val e = x - 1
                        val m = bars.firstOrNull { y - it.y1 <= 1 && s <= it.x1 && e >= it.x0 }
                        if (m != null) { m.y1 = y; m.x0 = min(m.x0, s); m.x1 = max(m.x1, e) }
                        else bars.add(Bar(y, y, s, e))
                    }
                } else x++
            }
        }
        val mobs = bars.filter { it.y1 - it.y0 >= 1 }
            .map { Pair((it.x0 + it.x1) / 2f, it.y1 + Config.BODY_OFFSET * H) }

        // Игрок всегда в центре экрана
        val px = W / 2f; val py = H / 2f
        val limit = (if (fleeing) Config.CLEAR else Config.DANGER) * H
        var vx = 0f; var vy = 0f; var near = 0
        for ((mx, my) in mobs) {
            val d = hypot(px - mx, py - my)
            if (d < limit) {
                near++
                val k = 1f / max(d * d, 1f)
                vx += (px - mx) * k; vy += (py - my) * k
            }
        }

        val svc = GestureService.instance
        val n = hypot(vx, vy)
        if (near > 0 && n > 1e-9f && svc != null) {
            fleeing = true
            val nx = vx / n; val ny = vy / n
            if (dirX == 0f && dirY == 0f) { dirX = nx; dirY = ny }
            else { dirX = 0.6f * dirX + 0.4f * nx; dirY = 0.6f * dirY + 0.4f * ny }
            val dn = max(hypot(dirX, dirY), 1e-6f); dirX /= dn; dirY /= dn
            val jx = Config.JOY_CX * realW; val jy = Config.JOY_CY * realH
            val r = Config.JOY_R * realH
            svc.steer(jx, jy, jx + dirX * r, jy + dirY * r)
        } else {
            fleeing = false; dirX = 0f; dirY = 0f
            svc?.release()
        }

        val now = System.currentTimeMillis()
        if (now - lastNotify > 1000) {
            lastNotify = now
            getSystemService(NotificationManager::class.java).notify(1, notif(
                "Мобов в кадре: ${mobs.size}, рядом: $near, бег: ${if (fleeing) "да" else "нет"}" +
                    if (svc == null) " (служба доступности выключена!)" else ""))
        }
    }

    private fun notif(text: String): Notification {
        val stop = PendingIntent.getService(this, 0, Intent(this, BotService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, "bot")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("MobDodger").setContentText(text)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Стоп", stop).build())
            .setOngoing(true).build()
    }

    override fun onDestroy() {
        running = false
        GestureService.instance?.release()
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
