package com.example.mobdodger

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Удерживает палец на джойстике и плавно меняет направление. */
class GestureService : AccessibilityService() {

    companion object {
        @Volatile var instance: GestureService? = null
        private const val STEP_MS = 120L
    }

    @Volatile private var wantActive = false
    @Volatile private var busy = false
    private var last: StrokeDescription? = null
    private var lastX = 0f; private var lastY = 0f
    @Volatile private var cx = 0f; @Volatile private var cy = 0f
    @Volatile private var tx = 0f; @Volatile private var ty = 0f

    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { release() }

    /** Двигать джойстик из центра (cx,cy) в точку (tx,ty). */
    fun steer(cx: Float, cy: Float, tx: Float, ty: Float) {
        this.cx = cx; this.cy = cy; this.tx = tx; this.ty = ty
        wantActive = true
        if (!busy) dispatchNext()
    }

    fun release() { wantActive = false }

    @Synchronized private fun dispatchNext() {
        val cont = wantActive
        if (!cont && last == null) return
        val path = Path()
        val stroke: StrokeDescription
        val prev = last
        if (prev == null) {
            path.moveTo(cx, cy); path.lineTo(tx, ty)
            stroke = StrokeDescription(path, 0, STEP_MS, cont)
            lastX = tx; lastY = ty
        } else {
            path.moveTo(lastX, lastY)
            if (cont) { path.lineTo(tx, ty); lastX = tx; lastY = ty } else path.lineTo(lastX + 0.1f, lastY)
            stroke = prev.continueStroke(path, 0, if (cont) STEP_MS else 10L, cont)
        }
        last = if (cont) stroke else null
        busy = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { busy = false; if (wantActive || last != null) dispatchNext() }
                override fun onCancelled(g: GestureDescription?) { busy = false; last = null }
            }, null)
        if (!ok) { busy = false; last = null }
    }
}
