# MobDodger
1. Откройте папку в Android Studio (Hedgehog+), дождитесь Gradle Sync.
2. Подключите телефон (отладка по USB) и нажмите Run, либо Build > Build APK.
3. На телефоне: Служба доступности > MobDodger > включить.
   (Android 13+: Настройки > Приложения > MobDodger > ⋮ > «Разрешить ограниченные настройки».)
4. «Запустить» > разрешить запись экрана > откройте игру.
Настройки: app/src/main/java/com/example/mobdodger/Config.kt
